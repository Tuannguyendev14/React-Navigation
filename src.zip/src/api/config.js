// export const API_URL = 'http://5e042286a7ad3700141a2078.mockapi.io';
export const API_URL = 'https://csm-api-staging.enouvo.com/api/v1';
